<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        Order Details
    </div>

<style>
    .datatable {
    width: 200% !important;
}
</style>
        <div class="card-body">
            <h3>Order No <strong>#<?php echo e($order->order_no ?? ''); ?></strong></h3><br/>
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-Order">
                    <thead>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.order.fields.id')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.blindid')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.order_no')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.customer')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.cust_ord_ref')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.cust_ord_no')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.quantity')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.blind_type')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.range')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.colour')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.stock_code')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.man_width')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.man_drop')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.blind_status')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.despatch_date')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.ordered')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.required')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.scheduled_date')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.roller_table')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.remake')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.same_day_despatch')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.over_size')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.man_location')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.order.fields.order_entered_by')); ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>

            <td>
                <?php echo e($order->id ?? ''); ?>

            </td>
            <td>
             <?php echo e($order->blindid ?? ''); ?>

            </td>
            <td>
             <?php echo e($order->order_no ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->customer ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->cust_ord_ref ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->cust_ord_no ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->quantity ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->blind_type ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->range ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->colour ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->stock_code ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->man_width ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->man_drop ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->blind_status ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->despatch_date ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->ordered ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->required ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->scheduled_date ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->roller_table ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->remake ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->same_day_despatch ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->over_size ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->man_location ?? ''); ?>

            </td>
            <td>
                <?php echo e($order->order_entered_by ?? ''); ?>

            </td>


        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div><div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
        <?php echo $orders->links(); ?>


    </div>
</div>

        <div class="card">
            <div class="card-header">
                Manufacturing History
            </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable-Order">
                    <thead>
                        <tr>
                            <th>
                                Full Name
                            </th>
                            <th>
                                Scanned Time
                            </th>
                            <th>
                                Process
                            </th>
                            <th>
                                Blind ID
                            </th>
                            <th>
                               Order No
                            </th>
                            <th>
                                Customer
                            </th>
                            <th>
                                CustOrdRef
                            </th>

                        </tr>
                    </thead>
                    <tbody>

                      <?php if($ordersem->isNotEmpty()): ?>
        <?php $__currentLoopData = $ordersem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td>
                <?php echo e($orderm->fullname ?? ''); ?>

            </td>
            <td>
                <?php echo e($orderm->scannedtime ?? ''); ?>

            </td>
            <td>
                <?php echo e($orderm->name ?? ''); ?>

            </td>
            <td>
                <?php echo e($orderm->blindid ?? ''); ?>

            </td>
            <td>
                <?php echo e($orderm->order_no ?? ''); ?>

            </td>
            <td>
                <?php echo e($orderm->customer ?? ''); ?>

            </td>
            <td>
                <?php echo e($orderm->cust_ord_ref ?? ''); ?>

            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <td colspan="7" class="text-center">
            No data available in table

      </td>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nasu\resources\views/admin/orders/vieworderno.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.orderhistory.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.orderhistories.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="order_number_id"><?php echo e(trans('cruds.orderhistory.fields.order_number')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('order_number') ? 'is-invalid' : ''); ?>" name="order_number_id" id="order_number_id">
                    <?php $__currentLoopData = $order_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $order_number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('order_number_id') == $id ? 'selected' : ''); ?>><?php echo e($order_number); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('order_number')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('order_number')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.orderhistory.fields.order_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/production.stylebyglobal.com/public_html/resources/views/admin/orderhistories/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.employee.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.employees.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="fullname"><?php echo e(trans('cruds.employee.fields.fullname')); ?></label>
                <input class="form-control <?php echo e($errors->has('fullname') ? 'is-invalid' : ''); ?>" type="text" name="fullname" id="fullname" value="<?php echo e(old('fullname', '')); ?>">
                <?php if($errors->has('fullname')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('fullname')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employee.fields.fullname_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="barcode"><?php echo e(trans('cruds.employee.fields.barcode')); ?></label>
                <input class="form-control <?php echo e($errors->has('barcode') ? 'is-invalid' : ''); ?>" type="text" name="barcode" id="barcode" value="<?php echo e(old('barcode', '')); ?>" required>
                <?php if($errors->has('barcode')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('barcode')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employee.fields.barcode_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="target"><?php echo e(trans('cruds.employee.fields.target')); ?></label>
                <input class="form-control <?php echo e($errors->has('target') ? 'is-invalid' : ''); ?>" type="number" name="target" id="target" value="<?php echo e(old('target', '')); ?>" step="1">
                <?php if($errors->has('target')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('target')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employee.fields.target_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="shift_id"><?php echo e(trans('cruds.employee.fields.shift')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('shift') ? 'is-invalid' : ''); ?>" name="shift_id" id="shift_id" required>
                    <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('shift_id') == $id ? 'selected' : ''); ?>><?php echo e($shift); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('shift')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('shift')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employee.fields.shift_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="team_id"><?php echo e(trans('cruds.employee.fields.team')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('team') ? 'is-invalid' : ''); ?>" name="team_id" id="team_id" required>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('team_id') == $id ? 'selected' : ''); ?>><?php echo e($team); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('team')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('team')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.employee.fields.team_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/production.stylebyglobal.com/public_html/resources/views/admin/employees/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.orders.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.order.title_singular')); ?>

            </a>
            <button class="btn btn-warning" data-toggle="modal" data-target="#csvImportModal">
                <?php echo e(trans('global.app_csvImport')); ?>

            </button>
            <?php echo $__env->make('csvImport.modal', ['model' => 'Order', 'route' => 'admin.orders.parseCsvImport'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.order.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Order">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.blindid')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.order_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.customer')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.cust_ord_ref')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.cust_ord_no')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.quantity')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.blind_type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.range')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.colour')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.stock_code')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.man_width')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.man_drop')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.blind_status')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.despatch_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.ordered')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.required')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.scheduled_date')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.roller_table')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.remake')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.same_day_despatch')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.over_size')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.man_location')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.order.fields.order_entered_by')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($order->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($order->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->blindid ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->order_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->customer ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->cust_ord_ref ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->cust_ord_no ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->quantity ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->blind_type ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->range ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->colour ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->stock_code ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->man_width ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->man_drop ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->blind_status ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->despatch_date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->ordered ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->required ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->scheduled_date ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->roller_table ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->remake ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->same_day_despatch ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->over_size ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->man_location ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($order->order_entered_by ?? ''); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.orders.show', $order->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.orders.edit', $order->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_delete')): ?>
                                    <form action="<?php echo e(route('admin.orders.destroy', $order->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php echo $orders->links(); ?>

</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.orders.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>
/*
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-Order:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})
*/
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/production.stylebyglobal.com/public_html/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>
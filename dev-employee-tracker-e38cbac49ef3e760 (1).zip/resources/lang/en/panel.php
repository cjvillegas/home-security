<?php

return [
    'site_title' => 'Employee Tracker',
];
